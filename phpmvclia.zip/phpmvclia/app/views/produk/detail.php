<div class="container mt-5"> 

<div class="card" style="width: 18rem;">
   <div class="card-body">
    <h5 class="card-title"><?= $data['plj']['nama produk']; ?></h5>
    <h6 class="card-subtitle mb-2 text-muted"><?= $data['plj']['kode produk'];?></h6>
    <p class="card-text"><?= $data['plj']['harga']; ?></p>
    <p class="card-text"><?= $data['plj']['jenis produk']; ?></p>
    <a href="<?=BASEURL; ?>/pelajar" class="card-link">kembali</a>
  </div>
</div>

</div>