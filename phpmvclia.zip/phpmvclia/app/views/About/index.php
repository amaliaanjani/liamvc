<br><section class="jumbotron text-center">
      <img src="img/aya.jpg" alt="anya" width="200" class="rounded-circle img-thumbnail" />
      <h1 class="display-4">rose des neiges</h1>
      <p class="lead"></p>
      <div class="row justify-content-center fs-5 text-center">
          <div class="col-4">
              my florist sells many kinds of flowers, ranging from Tulips, Rose, Baby's breath , Lilie, The hydrangea, Sunflower, and many more, shhh Let's stop by my flower shop and buy a lot of my merchandise here 💢 I'll give you a 𝟱𝟬% discount + bonus special edition just for 𝗬ou！🧚🏻‍♀💚</p>
          </div>
          </div>
        </div>
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
        <path
          fill="#ffffff"
          fill-opacity="1"
          d="M0,224L26.7,202.7C53.3,181,107,139,160,138.7C213.3,139,267,181,320,181.3C373.3,181,427,139,480,106.7C533.3,75,587,53,640,58.7C693.3,64,747,96,800,133.3C853.3,171,907,213,960,240C1013.3,267,1067,277,1120,256C1173.3,235,1227,181,1280,170.7C1333.3,160,1387,192,1413,208L1440,224L1440,320L1413.3,320C1386.7,320,1333,320,1280,320C1226.7,320,1173,320,1120,320C1066.7,320,1013,320,960,320C906.7,320,853,320,800,320C746.7,320,693,320,640,320C586.7,320,533,320,480,320C426.7,320,373,320,320,320C266.7,320,213,320,160,320C106.7,320,53,320,27,320L0,320Z"
        ></path>
      </svg>
    </section>